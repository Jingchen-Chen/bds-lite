# Gate checkpoint audit and unweighted ACDC addendum — 2026-11-15

Author scope: post hoc inference and presentation only; no training, tuning, push or
Zenodo upload. The author confirmed that the May test results informed gate-removal
reporting only, not architecture or hyperparameter selection. Original frozen evidence
and its interpretations remain unchanged. Checkpoint hashes and all 72 audit rows are
in checkpoint_audit.csv; every item uses seeds 1, 2 and 3 on each dataset.

## Checkpoint audit (before this addendum)

Use N = 1, 2, 3 and DS = isic2018, acdc, synapse in the paths below.

| Item | Actual checkpoint paths and family | Class weights | Label assessment |
|---|---|---|---|
| Main Inference cost: identity | results/checkpoints/DS_p1b_bdslite_full_current_seedN/best.pt; May follow-up, reused as retrained reference on ISIC2018/Synapse (ISIC tensor-identical to October F) | ACDC (1.5,1,1.25); other datasets none | Unqualified scope mixed the weighted ACDC set with current unweighted references; corrected by S19's new primary ACDC result |
| Main Discussion: identity | Same as Inference cost | Same | Same scope issue; new primary ACDC result supports unchanged wording |
| Main Discussion: nearly constant scale | Same paths on ISIC2018/Synapse; results/revision_runs/acdc_m6_full_unweighted_seedN/best.pt on ACDC | None | Consistent with retrained references |
| S19: identity | Same as Inference cost | ACDC weighted only | New unweighted primary result; old weighted result retained and labelled |
| S8 Table S18: identity (original) | outputs/runs/DS_bds_lite_full_seedN/best.pt; April original | None on all three datasets | Correct; no label change |
| S8 Table S19: identity (original) | Same April original checkpoints | None | Correct; no label change |
| S13 Table S28: gate structure | May follow-up reused as retrained on ISIC2018/Synapse; November unweighted ACDC (paths above) | None | Correct |
| S13 Table S28: gate modulation, band/off-band | Same as gate structure (M6 only) | None | Correct |

Tracing: Inference cost/S19 GID keys are read from gate_identity_effects.csv by
make_final_assets.py:630-639; gate_identity_analysis.py reads gate_identity_queue.json.
S8 S6g maps to extra_cohorts/famO_full_gateid in family_statistics.py and
figure_qualitative.prediction_file; evaluate_extra_cohorts.checkpoint resolves the
original checkpoints. Table S28's gate rows use M6 in boundary_transfer_probe.path_of;
gate_structure.py loads that same M6. The source/result history places the gate
structure and probe analyses after the November ACDC reference training. Nine
original, nine follow-up and three unweighted checkpoint configurations were inspected.

## New ACDC inference result

Identity minus full Boundary F1 = +0.000051701710813575194;
95% percentile interval [-0.0004237363067801286, +0.0003956254909119796].
Seeds 1–3; all 366 slices from the same 20 internal patients; shared eligibility
1098 image-class cells. This is fixed-checkpoint, patient-level uncertainty, not
inference over new training runs. Per-seed means: +0.00017607239815423166,
-0.00015043031408911337, +0.00012946304837560738.

The new driver invokes the unmodified recover_predictions.run_one and
gate_identity_analysis.main functions. Only the analysis ROOT and baseline file
resolver are redirected in memory. FP32 contiguous CUDA NCHW, batch16, argmax,
metrics, shared-cell eligibility, patient/seed averaging, bootstrap10,000 and
RNG20261102 match the existing analysis. Both full and identity conditions were
regenerated. Full-condition BF1 agrees exactly with all three archived unweighted
per-case files. A separate patient aggregation/bootstrap reproduces the mean and
interval within 1e-15 (numerical_verification.json). All seven original endpoints
and their original within-dataset Holm calculation are preserved in the new CSVs;
the requested BF1 summary does not change that family.

Requested results/checkpoints/acdc_m6_full_unweighted_seedN/best.pt paths are absent.
The existing completed checkpoints are under results/revision_runs/, as used by
study 1 and boundary_transfer_probe.path_of. No substitute model was chosen.
Both paths and the actual SHA-256 hashes are recorded in protocol.json/provenance.json.
The repository GPU lock was held; an unrelated 172 MiB detector process was recorded
and left running. This is accuracy inference, not a new timing profile.

The unchanged ISIC2018 mean (-0.001410) remains the largest absolute gate-identity
mean; therefore main-text 0.001 at three decimals and the Discussion statement
remain supported in the current retrained models. The old weighted ACDC result
(+0.000438, interval [+0.000230,+0.000658]) remains separate in S19.

## Preservation and presentation

S16's two original archives contain the Synapse seed1 config byte-for-byte, but
neither contains docs/devlog.md (including its lines833–841 and945–947).
S5 therefore cites '(development record)', as instructed. The author's confirmed
response paragraph is applied verbatim. No reason for choosing April models is added.
Main text and Limitations are unchanged; S8/S13 table labels and numbers are unchanged.
S5 adds the evaluation chronology and April parameter-setting statement; S19 explicitly
identifies the retrained primary models and class-weighted follow-up comparison;
S16 adds the new archive/manifest and describes Zenodo upload as planned only.

The additive archive is addendum-20261115.tar.gz; its standalone SHA-256 manifest
is addendum-20261115.sha256. Predictions and per-case outputs are included; no images,
reference masks or model checkpoint bytes are redistributed. Existing evaluator and
analysis source snapshots are included for inspecting/repeating the statistical step.

## Validation and delivery

Targeted builds: main.pdf 19 pages, supplement.pdf 42 pages, response_to_reviewers.pdf
rebuilt from response.md; all 119 template line-reference occurrences regenerated and
verified against the current numbered main PDF. check_response_quotes.py: 39 points,
0 problems. verify_final_assets.py: 200 checks, 0 mismatches. New S5/S19 pages visually
inspected. Main text, including Limitations and the Discussion, is byte-identical in
source and identical in extracted PDF text. Every pre-existing generated file is
byte-identical; only numbers_gate_addendum.tex is new. Existing frozen files: 2,832
unchanged SHA-256 hashes. The supplement retains an existing duplicate tab:inventory
label warning; this task does not change either label. No new unresolved references
or overfull boxes were found.

Ruff format/check pass (498 Python files); pytest 150 passed, 1 existing optional skip
with --basetemp on disk. No test was changed. Full asset regeneration was not needed:
the existing frozen generated files were retained; the new additive formatter and all
three PDF compilation/rendering steps were executed. The build entrypoint includes
that additive formatter for future builds. No manuscript number was altered except
the newly added unweighted ACDC gate effect; the old weighted result is still printed.
The response replacement and S5 chronology add the explicitly requested dates/seeds.

Commands: gate_identity_unweighted_acdc.py; make_gate_addendum_assets.py;
verify_final_assets.py; build_check.sh for main.tex and supplement.tex;
render_response.py; pandoc/tectonic for response_to_reviewers.pdf;
check_response_quotes.py; independent baseline/aggregation/bootstrap and frozen-hash
checks; PDF text/table preservation and line-reference checks; Ruff and full pytest.
Failed checks: none. Source path discrepancy was resolved by the canonical matching
run identities recorded above. No new training or Experiment C outcome was accessed.
