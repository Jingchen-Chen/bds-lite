"""Author-requested post hoc ACDC gate intervention, isolated from frozen evidence.

Reuse the frozen evaluator and analysis functions without editing their source.
Only ROOT and the baseline file resolver are redirected in memory for the analysis.
Run with PYTHONPATH=src:. PYTHONDONTWRITEBYTECODE=1 .venv/bin/python this_file.py.
"""

from __future__ import annotations

import csv
import fcntl
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import torch

from analysis.revision import gate_identity_analysis as analysis
from analysis.revision import recover_predictions as evaluator

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "revision/gate_identity_unweighted_acdc"


def sha(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2) + "\n")


def baseline(entry: dict) -> tuple[Path, Path]:
    folder = OUT / f"full/seed{entry['seed']}"
    return folder / "per_case.csv", folder / "predictions.npz"


def main() -> None:
    if OUT.exists():
        raise FileExistsError(f"Existing addendum preserved: {OUT}")
    manifest = ROOT / "recovered/followup/splits/acdc/test.json"
    ids = json.loads(manifest.read_text())["sample_ids"]
    patients = sorted({sid.split("_")[0] for sid in ids})
    if len(ids) != 366 or len(patients) != 20:
        raise ValueError("Expected the original 366 slices of 20 internal ACDC patients")
    sources = {
        str(p.relative_to(ROOT)): sha(p)
        for p in [
            Path(__file__),
            ROOT / "analysis/revision/recover_predictions.py",
            ROOT / "analysis/revision/gate_identity_analysis.py",
            ROOT / "src/bds_lite/evaluation/metrics.py",
            ROOT / "src/bds_lite/data/boundary.py",
            ROOT / "src/bds_lite/training/runner.py",
            ROOT / "src/bds_lite/utils/seed.py",
        ]
    }
    checkpoints = []
    entries = []
    for seed in (1, 2, 3):
        checkpoint = ROOT / f"results/revision_runs/acdc_m6_full_unweighted_seed{seed}/best.pt"
        payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
        config = payload["config"]
        if config["loss"].get("foreground_class_weights") is not None:
            raise ValueError("The requested ACDC reference must be unweighted")
        if config["project"]["seed"] != seed:
            raise ValueError("Checkpoint seed mismatch")
        checkpoints.append(
            dict(
                seed=seed,
                checkpoint=str(checkpoint.relative_to(ROOT)),
                checkpoint_sha256=sha(checkpoint),
                epoch=payload["epoch"],
                foreground_class_weights=None,
                requested_path=f"results/checkpoints/acdc_m6_full_unweighted_seed{seed}/best.pt",
                path_note="Requested path absent; canonical completed run path used by study 1",
            )
        )
        for condition in ("full", "identity"):
            entries.append(
                dict(
                    run_id=f"acdc_unweighted_{condition}_seed{seed}_test",
                    family="retrained_unweighted_acdc",
                    dataset="acdc",
                    seed=seed,
                    split="test",
                    checkpoint=str(checkpoint.relative_to(ROOT)),
                    checkpoint_sha256=sha(checkpoint),
                    manifest=str(manifest.relative_to(ROOT)),
                    manifest_sha256=sha(manifest),
                    batch=16,
                    classes=4,
                    force_gate_identity=condition == "identity",
                    output=str((OUT / f"{condition}/seed{seed}").relative_to(ROOT)),
                )
            )
        del payload
    OUT.mkdir()
    protocol = dict(
        scope="Author-authorized 2026-11-15 post hoc fixed-checkpoint addendum; no training",
        author_decision="May test evaluation informed gate-removal reporting only, not tuning",
        started_utc=datetime.now(timezone.utc).isoformat(),
        checkpoints=checkpoints,
        patients=patients,
        slices=len(ids),
        manifest=str(manifest.relative_to(ROOT)),
        manifest_sha256=sha(manifest),
        source_sha256=sources,
        evaluator="Unmodified recover_predictions.run_one; FP32 CUDA NCHW, batch16, argmax",
        analysis="Unmodified gate_identity_analysis.main; only ROOT/baseline I/O redirected",
        estimator="Shared finite image-class cells across both conditions and all three seeds; "
        "average within patient and across seeds; percentile bootstrap of 20 patient means",
        bootstrap_draws=10000,
        bootstrap_rng=20261102,
        all_endpoints="Original seven endpoints retained; BF1 is the requested summary",
        gpu_policy="Repository GPU lock; no unrelated process interrupted; no timing comparison",
        existing_gpu_processes=subprocess.check_output(
            ["nvidia-smi", "--query-compute-apps=pid,used_gpu_memory", "--format=csv,noheader"],
            text=True,
        ).strip(),
    )
    write_json(OUT / "protocol.json", protocol)
    write_json(OUT / "queue.json", dict(runs=entries))
    with (ROOT / "revision/.gpu.lock").open("a+") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for entry in entries:
            evaluator.run_one(entry, sha(OUT / "protocol.json"))
    # A second queue describes the same files relative to the isolated analysis ROOT.
    # The statistical function and all numerical settings remain byte-identical.
    relocated = []
    for entry in entries:
        if entry["force_gate_identity"]:
            row = dict(entry)
            row["output"] = f"identity/seed{entry['seed']}"
            relocated.append(row)
    (OUT / "revision/tables").mkdir(parents=True)
    write_json(OUT / "revision/gate_identity_queue.json", dict(runs=relocated))
    analysis.ROOT = OUT
    analysis.baseline = baseline
    analysis.main()
    results = list(csv.DictReader((OUT / "revision/tables/gate_identity_effects.csv").open()))
    bf1 = next(row for row in results if row["metric"] == "boundary_f1")
    if int(bf1["n"]) != 20:
        raise ValueError("All 20 internal patients must contribute")
    for name, digest in sources.items():
        if sha(ROOT / name) != digest:
            raise ValueError(f"Source changed during execution: {name}")
    write_json(
        OUT / "provenance.json",
        dict(
            protocol=protocol,
            protocol_sha256=sha(OUT / "protocol.json"),
            completed_utc=datetime.now(timezone.utc).isoformat(),
            boundary_f1=bf1,
            output_sha256={str(p.relative_to(OUT)): sha(p) for p in OUT.rglob("*") if p.is_file()},
        ),
    )
    print(json.dumps(bf1, indent=2))


if __name__ == "__main__":
    main()
