# ruff: noqa: E501
"""Page and line locations in the compiled revised manuscript, for the response letter.

Each anchor is a phrase that starts (and optionally a phrase that ends) a passage of the main text.
The script reads revision/manuscript/main.pdf with pdftotext -layout, keeps the numbered body lines
(the PeerJ template numbers every body line continuously), and finds each phrase after removing
whitespace and hyphens, so that line breaks and hyphenation do not matter. Floats (tables and
figures) are located by their caption label and reported by page. Supplement sections are located
in supplement.pdf by heading. It fails if any anchor is missing or occurs more than once.

Writes revision/manuscript/generated/letter_locations.tex (macros \\L@<key>) and
letter_locations.csv (key, page, first line, last line, phrase).

Usage: python analysis/revision/letter_locations.py
"""

from __future__ import annotations

import csv
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MS = ROOT / "revision/manuscript"
OUT = MS / "generated"

# key: (start phrase, end phrase or None)
ANCHORS = {
    "abstract": (
        "Training-only boundary supervision suits compact segmentation networks",
        "or a causal teacher-property effect.",
    ),
    "intro_contour": ("Shifting a contour by one pixel", "recommends reporting them with overlap"),
    "intro_compact": (
        "Segmentation networks have grown through attention gates",
        "the network that is kept (Related work).",
    ),
    "intro_gap": (
        "Three gaps limit what is known about distillation.",
        "can tell them apart.",
    ),
    "intro_approach": (
        "We address these gaps with a compact U-Net",
        "keeps the comparison controlled.",
    ),
    "intro_contrib": ("Our contributions are:", "where distillation gained."),
    "related": (
        "Boundary losses. Boundary loss integrates",
        "with their contributions and limitations.",
    ),
    "related_distill": (
        "Distillation. Knowledge distillation trains a student",
        "already has that supervision as the reference.",
    ),
    "arms": ("Every arm is a four-level 2D U-Net", "their evidence is summarized in"),
    "why_d": (
        "Why D, and not GSL or Boundary Loss, is the reference.",
        "not used as the reference for distillation.",
    ),
    "bds": ("Projection and gate (G).", "(training step: Supplementary S2)."),
    "alpha": ("so the gate is per-pixel and per-channel.", "(Supplementary S11 varies it)."),
    "focal": (
        "Losses that reweight small or hard structures",
        "so that every arm shares one segmentation loss.",
    ),
    "stopgrad": ("where the stop-gradient operator", "the transfer runs one way."),
    "sdf": ("Surface loss (S).", "GSL comparators: Supplementary S2)."),
    "routes": (
        "Boundary supervision can reach the deployed output by three routes",
        "it need not change before other metrics.",
    ),
    "kd_method": (
        "D+KD-band keeps D and its losses and adds a loss from a separate teacher.",
        "were not tuned (Supplementary S17).",
    ),
    "kd_controls": (
        "Controls for the band and the teacher.",
        "with one teacher trained per configuration.",
    ),
    "datasets": ("provides dermoscopic images with one lesion class", "approval was not required."),
    "why_tasks": (
        "The tasks differ in the number and size of structures",
        "a controlled scale of difficulty.",
    ),
    "liver_brain": (
        "Supplementary S3 explains why liver-tumor",
        "segmentation were not added.",
    ),
    "isic_test": (
        "ISIC2018 models are evaluated on the official test set",
        "without near-duplicates (Supplementary S4).",
    ),
    "preprint": (
        "An earlier version of this manuscript is publicly available",
        "official-test results reported here (Supplementary S4).",
    ),
    "official_acdc": ("For ACDC, stages 1", "cannot be measured (Supplementary S18)."),
    "training": ("All runs used AdamW", "and PyTorch 2.11.0."),
    "selection": (
        "The checkpoint with maximum validation DSC was kept",
        "as disclosed below.",
    ),
    "kd_select": (
        "ACDC was selected post hoc from the original stage-2 analysis",
        "of between-seed variance)",
    ),
    "expc": (
        "A further confirmation (Experiment C) was stopped",
        "none of its results is used (Supplementary S15).",
    ),
    "followup_design": (
        "Follow-up controls. D+KD-full and",
        "can change the stage-3 decision.",
    ),
    "metrics": ("Predictions are the argmax over classes", "data and are not reported."),
    "stats": (
        "Recipe-level contrasts. The unit of replication",
        "not as estimates of one common effect.",
    ),
    "sesoi": ("The SESOI are engineering thresholds", "defines how each interval is read."),
    "decision_rules": (
        "In the ISIC2018 extension, the six contrasts among the four ten-run arms",
        "are labeled post hoc.",
    ),
    "resolve": (
        "On ISIC2018 the standard deviation of Boundary F1",
        "run-level intervals within one pipeline.",
    ),
    "reference": (
        "Pooled over the three datasets with three runs per arm, D minus U",
        "did not hold in the earlier pipeline (Supplementary S15).",
    ),
    "transfer": (
        "Distillation and gate. Adding F and G to D",
        "forest plot in Supplementary S13).",
    ),
    "mechanism": ("Probes and gate (post hoc).", "of pixel labels in any model."),
    "kd_explo": (
        "Stage 2 (exploratory). With three runs per arm",
        "also did not establish a gain (Supplementary S17).",
    ),
    "kd_rep": ("Stage 3 (pre-registered confirmatory).", "changes no pre-specified reading."),
    "kd_secondary": ("Secondary results, descriptive and unadjusted", "the highest run of D was"),
    "kd_amend": ("A pre-test integrity amendment", "documented in Supplementary S18."),
    "followup": (
        "Against D, full-image distillation from the same teacher",
        "absence of useful teacher information.",
    ),
    "other_arms": (
        "summarizes the evidence for the remaining arms",
        "the purpose for which it was included.",
    ),
    "full_recipe": (
        "On ISIC2018 in the retrained set, BDS-Lite scored below D over ten runs per arm",
        "it is not assigned to distillation.",
    ),
    "attribution": (
        "In the additive model over the eight ablation cells",
        "the purpose for which it was included.",
    ),
    "errors": (
        "Error location. Most ISIC2018 error pixels lay away from the contour",
        "(Supplementary S8).",
    ),
    "errloc": ("In a post hoc analysis of D on the official ACDC patients", "D scored lower"),
    "allcase": ("Because primary HD95 and ASSD skip missed structures", "(Supplementary S8)."),
    "cost": (
        "Cost. D and all external-teacher arms deploy the U-Net graph",
        "restores the U-Net graph (Supplementary S19).",
    ),
    "kd_cost": (
        "The cost of external-teacher distillation lies in training",
        "by construction (Supplementary S18).",
    ),
    "disc_when": (
        "A gain over the training-only boundary decoder was established in one setting",
        "remains open.",
    ),
    "disc_mechanism": (
        "A teacher that scores below its students",
        "both teachers were trained once.",
    ),
    "disc_designs": (
        "BDS-Lite's teacher, the boundary decoder",
        "trained separately from the student.",
    ),
    "disc_errors": (
        "Direct band supervision targets pixels near the teacher contour",
        "regression toward the mean, would also produce.",
    ),
    "stage_shift": (
        "The ACDC Boundary F1 mean of D was",
        "would affect the stage-3 and follow-up contrasts alike.",
    ),
    "practical": (
        "For a compact network, D provides a reference",
        "leaves the inference graph unchanged.",
    ),
    "practical_kd": (
        "A gain from distillation should be checked against the same loss",
        "leaves the inference graph unchanged.",
    ),
    "clinical": (
        "The error types relate differently to clinical use",
        "that we could not compute.",
    ),
    "limitations": (
        "Stage-1 and stage-2 contrasts rest on three runs per arm",
        "anatomical naming (Supplementary S3--S5).",
    ),
    "attribution_limits": (
        "Attribution within D+KD-band.",
        "selected for confirmation after the exploratory results",
    ),
    "slices": (
        "Slices are processed and scored independently",
        "penalize the resulting inconsistency",
    ),
    "nnunet": ("We did not run nnU-Net", "(Supplementary S15)."),
    "augmentation": (
        "One compact backbone was studied without augmentation",
        "incomplete at the editorial cutoff.",
    ),
    "conclusions": (
        "We asked when boundary distillation adds to the training-only",
        "to which a gain is attributed.",
    ),
    "data_avail": (
        "Code, configurations, split manifests, per-case results",
        "summary statistics only.",
    ),
}
SUPP = [f"S{i}" for i in range(1, 23)]
LIGATURES = {"ﬁ": "fi", "ﬂ": "fl", "ﬀ": "ff", "ﬃ": "ffi", "ﬄ": "ffl", "’": "'", "‘": "'"}


def norm(text: str) -> str:
    for a, b in LIGATURES.items():
        text = text.replace(a, b)
    return re.sub(r"[\s\-−–—­]", "", text).lower()


def pages(pdf: Path) -> list[str]:
    n = int(
        re.search(
            r"Pages:\s+(\d+)",
            subprocess.run(["pdfinfo", str(pdf)], capture_output=True, text=True).stdout,
        ).group(1)
    )
    return [
        subprocess.run(
            ["pdftotext", "-layout", "-f", str(i), "-l", str(i), str(pdf), "-"],
            capture_output=True,
            text=True,
            check=True,
        ).stdout
        for i in range(1, n + 1)
    ]


def body_index(texts: list[str]) -> tuple[str, list[tuple[int, int]]]:
    """Concatenated normalized body text and, per character, (page, line)."""
    chars, where = [], []
    for page, text in enumerate(texts, start=1):
        for raw in text.splitlines():
            m = re.match(r"^\s{0,8}(\d{1,4})\s+(\S.*)$", raw)
            if not m:
                continue
            piece = norm(m.group(2))
            chars.append(piece)
            where.extend([(page, int(m.group(1)))] * len(piece))
    return "".join(chars), where


def locate(body: str, where: list, phrase: str, start: int = 0) -> tuple[int, int]:
    key = norm(phrase)
    first = body.find(key, start)
    if first < 0:
        raise ValueError(f"anchor not found: {phrase!r}")
    if start == 0 and body.find(key, first + 1) >= 0:
        raise ValueError(f"anchor not unique: {phrase!r}")
    return first, first + len(key) - 1


def main() -> int:
    main_pages = pages(MS / "main.pdf")
    body, where = body_index(main_pages)
    rows, macros = [], []
    for key, (start, end) in ANCHORS.items():
        s0, s1 = locate(body, where, start)
        e1 = locate(body, where, end, s1)[1] if end else s1
        (p0, l0), (p1, l1) = where[s0], where[e1]
        if l1 - l0 > 60:
            raise ValueError(f"{key}: end anchor too far from start ({l0}-{l1})")
        text = (
            f"p.~{p0}, l.~{l0}"
            if l0 == l1
            else (f"p.~{p0}, ll.~{l0}--{l1}" if p0 == p1 else f"pp.~{p0}--{p1}, ll.~{l0}--{l1}")
        )
        rows.append((key, p0, l0, l1, start))
        macros.append(f"\\expandafter\\def\\csname L@{key}\\endcsname{{{text}}}")
        macros.append(f"\\expandafter\\def\\csname L@{key}@start\\endcsname{{p.~{p0}, l.~{l0}}}")
        macros.append(f"\\expandafter\\def\\csname L@{key}@end\\endcsname{{p.~{p1}, l.~{l1}}}")
    supp_pages = pages(MS / "supplement.pdf")
    # Float names and pages follow the sources and PDFs, so a move to the supplement
    # cannot silently leave the response letter pointing to an obsolete number.
    for source, texts, prefix in (
        (MS / "main.tex", main_pages, ""),
        (MS / "supplement.tex", supp_pages, "S"),
    ):
        # Read actual LaTeX numbering: longtables in generated inputs also advance
        # the supplementary table counter, even when they have no caption.
        aux = source.with_suffix(".aux").read_text()
        for match in re.finditer(
            r"\\begin\{(table|figure)\}(?:\[[^]]*\])?.*?\\end\{\1\}",
            source.read_text(),
            re.S,
        ):
            kind = match.group(1)
            label_match = re.search(r"\\label\{([^}]+)\}", match.group())
            if label_match is None:
                continue
            key = label_match.group(1)
            compiled = re.search(r"\\newlabel\{" + re.escape(key) + r"\}\{\{([^}]+)\}", aux)
            if compiled is None:
                raise ValueError(f"compiled label missing: {key}")
            name = f"{kind.title()} {compiled.group(1)}"
            hits = [
                i
                for i, text in enumerate(texts, start=1)
                if re.search(r"^\s*" + re.escape(name) + r"[.:]", text, re.M)
            ]
            if len(hits) != 1:
                raise ValueError(f"{name} found on pages {hits}")
            rows.append((key, hits[0], "", "", name))
            macros.append(f"\\expandafter\\def\\csname L@{key}\\endcsname{{p.~{hits[0]}}}")
            display = ("Supplementary " if prefix else "") + name.replace(" ", "~")
            macros.append(f"\\expandafter\\def\\csname F@{key}\\endcsname{{{display}}}")
    for s in SUPP:
        hits = [
            i
            for i, t in enumerate(supp_pages, start=1)
            if re.search(r"^\s*" + re.escape(s) + r"\.\s", t, re.M)
        ]
        if not hits:
            raise ValueError(f"supplement section {s} not found")
        rows.append((s, hits[0], "", "", f"Supplementary {s}"))
        macros.append(
            f"\\expandafter\\def\\csname L@{s}\\endcsname{{Supplementary {s}, p.~{hits[0]}}}"
        )
    (OUT / "letter_locations.tex").write_text(
        "% generated by analysis/revision/letter_locations.py from main.pdf and supplement.pdf; do not edit\n"
        + "\n".join(macros)
        + "\n"
    )
    with (OUT / "letter_locations.csv").open("w", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(["key", "page", "first_line", "last_line", "anchor"])
        writer.writerows(rows)
    print(f"{len(rows)} locations")
    return 0


if __name__ == "__main__":
    sys.exit(main())
