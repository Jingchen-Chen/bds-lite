# ruff: noqa: E501
"""DRAFT Fig. 1 (vector redraw) for author approval; does not replace the manuscript figure.

The current Fig. 1 (revision/figures/architecture.png) is a raster with no editable source
(revision/RESTRUCTURE_PHASE1_AUDIT.md, section 1.2). This script redraws it in matplotlib,
keeping its layout and sampled palette, and changes only what the Methods text and the code
define differently:

- loss and weight names as in Eqs. 1-6: L_boundary, L_sdf, lambda_d; no lambda_seg (= 1);
- boundary head 1x1, c_b -> 1 (boundary_classes = 1 in every config; z_b is single-channel);
- projection named P; boundary prediction sigma(z_b) (the old "P_b" clashed with P);
- output convolution W_o and logits z_s as in Eq. 1;
- component letters D, F, G, S as in Table 1; the surface loss S is drawn in panel (c);
- new panel (d): D+KD-band (Eq. 6), external teacher, training only.

Outputs (drafts only):
- revision/figures/drafts/architecture_v3_draft.{pdf,png};
- revision/figures/drafts/fig1_side_by_side.png (current | draft).

    .venv/bin/python analysis/revision/figure_architecture_v3.py
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import Circle, FancyArrowPatch, FancyBboxPatch  # noqa: E402
from PIL import Image, ImageDraw, ImageFont  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "revision/figures/drafts"
CURRENT = ROOT / "revision/figures/architecture.png"

# palette sampled from the current figure (fills) with matching edges
BLUE_FILL, BLUE_EDGE, BLUE_LINE = "#edf3fb", "#7895cb", "#04297a"
ORANGE_FILL, ORANGE_EDGE = "#fbf4e7", "#f09340"
GATE_FILL, GATE_EDGE = "#fef9f5", "#e8622c"
LOSS_FILL, LOSS_EDGE = "#fcebeb", "#e55b5b"
GRAY_FILL, GRAY_EDGE = "#f7f8f9", "#81848c"
TEXT = "#1a1a1a"
STYLE = {
    "blue": (BLUE_FILL, BLUE_EDGE),
    "orange": (ORANGE_FILL, ORANGE_EDGE),
    "gate": (GATE_FILL, GATE_EDGE),
    "loss": (LOSS_FILL, LOSS_EDGE),
    "gray": (GRAY_FILL, GRAY_EDGE),
}
FS = 9.5

plt.rcParams.update(
    {"font.family": "DejaVu Sans", "mathtext.fontset": "dejavusans", "font.size": FS}
)


def box(ax, x, y, w, h, text, kind="blue", fs=FS, lw=1.6, weight="normal", va="center"):
    fill, edge = STYLE[kind]
    ax.add_patch(
        FancyBboxPatch(
            (x, y),
            w,
            h,
            boxstyle="round,pad=0,rounding_size=0.9",
            fc=fill,
            ec=edge,
            lw=lw if kind != "gate" else 2.2,
        )
    )
    if text:
        ty = y + h / 2 if va == "center" else y + h - 1.2
        ax.text(
            x + w / 2,
            ty,
            text,
            ha="center",
            va=va,
            fontsize=fs,
            color=TEXT,
            linespacing=1.35,
            fontweight=weight,
        )


def tag(ax, x, y, letter, color=ORANGE_EDGE):
    ax.add_patch(Circle((x, y), 1.25, fc="white", ec=color, lw=1.4, zorder=5))
    ax.text(
        x,
        y,
        letter,
        ha="center",
        va="center",
        fontsize=8.5,
        fontweight="bold",
        color=color,
        zorder=6,
    )


def path(ax, pts, color, arrow=True, lw=1.6, ls="-"):
    for a, b in zip(pts[:-2], pts[1:-1], strict=False):
        ax.plot([a[0], b[0]], [a[1], b[1]], color=color, lw=lw, ls=ls, solid_capstyle="butt")
    ax.add_patch(
        FancyArrowPatch(
            pts[-2],
            pts[-1],
            arrowstyle="-|>" if arrow else "-",
            mutation_scale=11,
            color=color,
            lw=lw,
            ls=ls,
            shrinkA=0,
            shrinkB=0,
        )
    )


def blue(ax, *pts):
    path(ax, list(pts), BLUE_LINE)


def orange(ax, *pts, ls="-"):
    path(ax, list(pts), ORANGE_EDGE, ls=ls)


def title(ax, x, y, text):
    ax.text(x, y, text, fontsize=11.5, fontweight="bold", color=TEXT, va="center")


def draw() -> plt.Figure:
    fig = plt.figure(figsize=(11.0, 8.6))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 110)
    ax.set_ylim(0, 86)
    ax.axis("off")

    # ------------------------------------------------------------- (a) architecture
    ax.text(
        1,
        83.5,
        "(a) BDS-Lite (arm D+F+G+S)",
        fontsize=12.5,
        fontweight="bold",
        color=TEXT,
        va="center",
    )
    # legend
    lx, ly = 64, 77.3
    ax.add_patch(
        FancyBboxPatch(
            (lx, ly),
            45,
            8.0,
            boxstyle="round,pad=0,rounding_size=1",
            fc="white",
            ec="#9a9a9a",
            ls="--",
            lw=1.2,
        )
    )
    items = [
        ("arrow", BLUE_LINE, "inference path (deployed)"),
        ("arrow", ORANGE_EDGE, "training only"),
        ("blue", None, "deployed component"),
        ("orange", None, "training-only component"),
        ("gate", None, r"gate (deployed; identity at $\alpha=0$)"),
        ("loss", None, "loss term"),
    ]
    for i, (kind, color, label) in enumerate(items):
        cx = lx + 1.5 + (i % 2) * 24.5
        cy = ly + 6.3 - (i // 2) * 2.4
        if kind == "arrow":
            ax.add_patch(
                FancyArrowPatch(
                    (cx, cy),
                    (cx + 3.2, cy),
                    arrowstyle="-|>",
                    mutation_scale=9,
                    color=color,
                    lw=1.5,
                )
            )
        else:
            fill, edge = STYLE[kind]
            ax.add_patch(
                FancyBboxPatch(
                    (cx, cy - 0.7),
                    3.2,
                    1.4,
                    boxstyle="round,pad=0,rounding_size=0.3",
                    fc=fill,
                    ec=edge,
                    lw=1.4,
                )
            )
        ax.text(cx + 4.0, cy, label, va="center", fontsize=8.3, color=TEXT)

    # input and encoder
    box(ax, 1, 57, 7.5, 10, "Input\n$H\\times W\\times C$", "gray", weight="bold")
    blue(ax, (8.5, 62), (10, 62))
    box(ax, 10, 51.5, 34, 16, "", "blue", lw=1.8)
    ax.text(
        27,
        53.6,
        "Shared encoder $E$",
        ha="center",
        va="center",
        fontsize=FS + 0.5,
        color=BLUE_LINE,
        fontweight="bold",
    )
    for i, ch in enumerate(["$c$", "$2c$", "$4c$", "$8c$"]):
        sx = 11.5 + i * 8.0
        box(ax, sx, 56, 7.0, 9.5, f"Stage {i + 1}\n{ch}", "blue", fs=FS)
        if i < 3:
            blue(ax, (sx + 7.0, 60.75), (sx + 8.0, 60.75))
    # skip connections into D_s (multi-scale features; they also feed D_b)
    for i in range(3):
        sx = 11.5 + i * 8.0 + 3.5
        level = 72.5 + i * 1.2
        path(ax, [(sx, 65.5), (sx, 71), (sx, level), (47, level)], BLUE_LINE, lw=1.3)
    ax.text(29, 76.6, "multi-scale features (also to $D_b$)", ha="center", fontsize=8.5, color=TEXT)
    blue(ax, (44, 62), (45.5, 62), (45.5, 69), (47, 69))
    orange(ax, (45.5, 62), (45.5, 52), (47, 52))

    # segmentation path
    box(ax, 47, 66, 19, 10, "Segmentation decoder $D_s$\n(Up$\\times$3 $\\to c$)", "blue")
    blue(ax, (66, 71), (68.3, 71))
    ax.text(66.7, 72.3, "$F_s$ ($c$)", fontsize=FS - 0.5, color=TEXT)
    ax.add_patch(Circle((69.3, 71), 1.0, fc="white", ec=BLUE_LINE, lw=1.6))
    ax.text(69.3, 71, r"$\times$", ha="center", va="center", fontsize=11, color=BLUE_LINE)
    blue(ax, (70.3, 71), (72, 71))
    box(
        ax,
        72,
        64.5,
        17.5,
        11.5,
        "Gate\n$F_s^{\\mathrm{m}}=F_s\\odot[1+\\alpha(g-0.5)]$\n$g=\\sigma(W_gq_s+b_g)$, $\\alpha=0.25$",
        "gate",
        fs=FS - 0.3,
    )
    tag(ax, 89.1, 75.6, "G", GATE_EDGE)
    blue(ax, (89.5, 70.25), (92.5, 70.25))
    ax.text(89.9, 71.3, "$F_s^{\\mathrm{m}}$", fontsize=FS - 0.5, color=TEXT)
    box(ax, 92.5, 67.5, 7, 5.5, "$W_o$\n1$\\times$1, $c\\to K$", "blue", fs=FS - 0.5)
    blue(ax, (99.5, 70.25), (101, 70.25))
    box(ax, 101, 66.5, 8, 7.5, "logits $z_s$\n$K\\times H\\times W$", "blue", fs=FS - 0.5)

    # projection and distillation
    blue(ax, (67.6, 71), (67.6, 63))
    box(ax, 63.5, 58, 8.2, 5, "$P$: 1$\\times$1\n$c\\to c_b$", "blue", fs=FS - 0.5)
    blue(ax, (71.7, 60.5), (73.5, 60.5))
    box(ax, 73.5, 58, 6.5, 5, "$q_s$ ($c_b$)", "blue", fs=FS - 0.5)
    blue(ax, (76.75, 63), (76.75, 64.5))
    orange(ax, (80, 60.5), (83, 60.5))
    box(
        ax,
        83,
        54.5,
        15,
        8.5,
        "$L_{\\mathrm{distill}}=$\nSmoothL1$(q_s,\\,\\mathrm{sg}(q_b))$",
        "loss",
        fs=FS - 0.3,
    )
    tag(ax, 97.6, 62.6, "F")

    # boundary path
    box(ax, 47, 47, 19, 10, "Boundary decoder $D_b$\n(Up$\\times$3 $\\to c_b$)", "orange")
    tag(ax, 65.6, 56.6, "D")
    orange(ax, (66, 52), (70.5, 52), (81, 52), (81, 56.5), (83, 56.5))
    ax.text(66.6, 53.0, "$q_b$ ($c_b$)", fontsize=FS - 0.5, color=TEXT)
    ax.text(81.4, 53.3, "sg", fontsize=FS - 1, color=TEXT, style="italic")
    orange(ax, (70.5, 52), (70.5, 48), (72.5, 48))
    box(ax, 72.5, 45.5, 9, 5, "1$\\times$1, $c_b\\to1$", "orange", fs=FS - 0.5)
    orange(ax, (81.5, 48), (84, 48))
    box(ax, 84, 45.5, 10, 5, "$z_b$ ($1\\times H\\times W$)", "orange", fs=FS - 0.5)
    orange(ax, (94, 48), (97, 48))
    box(ax, 97, 45.5, 12, 5, "$L_{\\mathrm{boundary}}$, see (b)", "loss", fs=FS - 0.5)

    # dividers
    ax.plot([0.5, 109.5], [44, 44], color="#b8c0cc", ls="--", lw=1.2)
    for x in (37.5, 72.5):
        ax.plot([x, x], [23.5, 44], color="#b8c0cc", ls="--", lw=1.2)
    ax.plot([0.5, 109.5], [23.5, 23.5], color="#b8c0cc", ls="--", lw=1.2)

    # ------------------------------------------------------------- (b) boundary supervision
    title(ax, 1, 41.8, "(b) Boundary supervision")
    tag(ax, 25.5, 41.8, "D")
    box(ax, 1.5, 33.5, 8.5, 5, "$z_b$ from (a)", "orange", fs=FS - 0.5)
    orange(ax, (10, 36), (12, 36))
    box(ax, 12, 33.5, 9, 5, "$\\sigma(z_b)$", "orange", fs=FS)
    orange(ax, (21, 36), (26.5, 36), (26.5, 34.5), (27.5, 34.5))
    box(ax, 1.5, 25, 8.5, 6.5, "reference\nmask $y$", "gray", fs=FS - 0.5)
    orange(ax, (10, 28.25), (12, 28.25))
    box(
        ax,
        12,
        25,
        13,
        6.5,
        "dilation XOR erosion\n(3$\\times$3, 4-conn.),\nunion over classes",
        "orange",
        fs=FS - 1.2,
    )
    orange(ax, (25, 28.25), (26.5, 28.25), (26.5, 30.5), (27.5, 30.5))
    ax.text(25.2, 26.5, "$y_b$", fontsize=FS - 0.5, color=TEXT)
    box(
        ax,
        27.5,
        28.5,
        9.5,
        8,
        "$\\lambda_bL_{\\mathrm{boundary}}$\nBCE + Dice",
        "loss",
        fs=FS - 0.5,
    )

    # ------------------------------------------------------------- (c) seg + surface
    title(ax, 38.5, 41.8, "(c) Segmentation and surface")
    box(ax, 39, 33.5, 8.5, 5, "$z_s$ from (a)", "blue", fs=FS - 0.5)
    blue(ax, (47.5, 36), (49.5, 36))
    box(ax, 49.5, 33.5, 9.5, 5, "$p=$softmax$(z_s)$", "blue", fs=FS - 1.6)
    box(ax, 39, 25, 8.5, 6.5, "reference\nmask $y$", "gray", fs=FS - 0.5)
    orange(ax, (47.5, 28.25), (49.5, 28.25))
    box(ax, 49.5, 25, 9.5, 6.5, "signed dist.\n$\\phi_{nk}/s_{nk}$", "orange", fs=FS - 0.8)
    orange(ax, (59, 36), (62, 36))
    box(ax, 62, 33, 10, 6, "$L_{\\mathrm{seg}}(p,y)$\nCE + Dice", "loss", fs=FS - 0.8)
    orange(ax, (60.5, 36), (60.5, 30.2), (62, 30.2))
    orange(ax, (59, 27.0), (62, 27.0))
    box(
        ax,
        62,
        24.8,
        10,
        6.6,
        "$\\lambda_{\\mathrm{sdf}}L_{\\mathrm{sdf}}$\n$\\sum p\\,\\phi/s$",
        "loss",
        fs=FS - 0.8,
    )
    tag(ax, 71.6, 31.2, "S")

    # ------------------------------------------------------------- (d) D+KD-band
    title(ax, 73.5, 41.8, "(d) D+KD-band (external teacher)")
    box(
        ax,
        74,
        33,
        15,
        6.5,
        "teacher: U-Net, ResNet-34\n(ImageNet-pretrained),\ntrained once, frozen",
        "orange",
        fs=FS - 1.9,
    )
    orange(ax, (89, 36.25), (91, 36.25))
    box(ax, 91, 33, 8, 6.5, "cached\n$p^{t}$", "orange", fs=FS - 0.5)
    orange(ax, (99, 37.0), (100.5, 37.0))
    orange(ax, (95, 33), (95, 31.5))
    box(ax, 91, 25, 8, 6.5, "band $B$:\ndil.$-$ero.\nof argmax $p^t$", "orange", fs=FS - 1.6)
    orange(ax, (99, 28.25), (100.5, 28.25))
    box(
        ax,
        74,
        25,
        15,
        6.5,
        "student $p$: arm D\n(no $P$, F, G, S;\ndeploys as U-Net)",
        "blue",
        fs=FS - 1.4,
    )
    orange(ax, (81.5, 25), (81.5, 24.2), (104.75, 24.2), (104.75, 25.5))
    box(
        ax,
        100.5,
        25.5,
        8.8,
        13,
        "$\\lambda_{\\mathrm{kd}}L_{\\mathrm{kd}}$\nCE($p^t$, $p$)\nin $B$",
        "loss",
        fs=FS - 0.8,
    )

    # ------------------------------------------------------------- objectives
    ax.add_patch(
        FancyBboxPatch(
            (1, 1.5),
            108,
            19.5,
            boxstyle="round,pad=0,rounding_size=0.6",
            fc="#f8f9fa",
            ec="#c0c9d5",
            lw=1.6,
        )
    )
    ax.text(
        3, 18.6, "Training objectives", fontsize=11.5, fontweight="bold", color=TEXT, va="center"
    )
    lines = [
        r"BDS-Lite (D+F+G+S):  $L=L_{\mathrm{seg}}+\lambda_{\mathrm{sdf}}L_{\mathrm{sdf}}+\lambda_bL_{\mathrm{boundary}}+\lambda_dL_{\mathrm{distill}}$,   $\lambda_{\mathrm{sdf}}=1$, $\lambda_b=\lambda_d=0.05$",
        r"D:  $L=L_{\mathrm{seg}}+\lambda_bL_{\mathrm{boundary}}$;   other arms drop terms or set $\alpha=0$ (Table 1)",
        r"D+KD-band:  $L=L_{\mathrm{seg}}+\lambda_bL_{\mathrm{boundary}}+\lambda_{\mathrm{kd}}L_{\mathrm{kd}}$,   $\lambda_{\mathrm{kd}}=1$",
        r"At deployment $D_b$, the teacher and all losses are removed; $P$ and the gate remain (identity at $\alpha=0$).",
    ]
    for i, line in enumerate(lines):
        ax.text(3, 15.2 - i * 3.2, line, fontsize=FS + 0.3, color=TEXT, va="center")
    sym = [
        r"$c=32$: base channels",
        r"$c_b=\max(c/2,8)=16$",
        r"$K$: number of classes",
        r"sg: stop-gradient",
        r"D, F, G, S: components (Table 1)",
    ]
    for i, line in enumerate(sym):
        ax.text(83, 15.2 - i * 2.9, line, fontsize=FS, color=TEXT, va="center")
    return fig


def side_by_side(draft_png: Path, out: Path) -> None:
    cur = Image.open(CURRENT).convert("RGB")
    new = Image.open(draft_png).convert("RGB")
    width = 2400
    cur = cur.resize((width, round(cur.height * width / cur.width)), Image.LANCZOS)
    new = new.resize((width, round(new.height * width / new.width)), Image.LANCZOS)
    head, gap = 110, 60
    canvas = Image.new("RGB", (2 * width + gap, head + max(cur.height, new.height)), "white")
    canvas.paste(cur, (0, head))
    canvas.paste(new, (width + gap, head))
    draw = ImageDraw.Draw(canvas)
    draw.line(
        [(width + gap // 2, 20), (width + gap // 2, canvas.height - 20)], fill="#999999", width=3
    )
    try:
        font = ImageFont.truetype("DejaVuSans-Bold.ttf", 54)
    except OSError:
        font = ImageFont.load_default()
    draw.text((30, 25), "Current Fig. 1 (manuscript)", fill="black", font=font)
    draw.text(
        (width + gap + 30, 25),
        "Draft revised Fig. 1 (not in manuscript)",
        fill="#b03000",
        font=font,
    )
    canvas.save(out)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    fig = draw()
    fig.savefig(OUT / "architecture_v3_draft.pdf")
    fig.savefig(OUT / "architecture_v3_draft.png", dpi=330)
    plt.close(fig)
    side_by_side(OUT / "architecture_v3_draft.png", OUT / "fig1_side_by_side.png")
    print("wrote", OUT)


if __name__ == "__main__":
    main()
