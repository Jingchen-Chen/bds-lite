# ruff: noqa: E501
"""Table and figure for the central question: what does distillation add to a boundary decoder?

Reads only the frozen outputs revision/tables/families/expansion_interaction.csv and
expansion_contrasts.csv (seeds 1-3 on all datasets, seeds 1-10 on ISIC2018). Nothing is recomputed.

Writes generated/tab_central.tex and revision/figures/central_question.pdf.
"""

from __future__ import annotations

import csv
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402
from matplotlib.patches import Patch  # noqa: E402
from matplotlib.transforms import blended_transform_factory  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]
FAM = ROOT / "revision/tables/families"
GEN = ROOT / "revision/manuscript/generated"
FIG = ROOT / "revision/figures"
DATASETS = ["isic2018", "acdc", "synapse"]
NAMES = {"isic2018": "ISIC2018", "acdc": "ACDC", "synapse": "Synapse"}
METRICS = [("boundary_f1", "Boundary F1", 3), ("dsc", "DSC", 3), ("hd95", "HD95 (px)", 2)]
EFFECTS = [
    ("decoder without surface", "Decoder vs U-Net"),
    ("distillation+gate without surface", "Transfer, no surface loss"),
    ("distillation+gate with surface", "Transfer, with surface loss"),
]
INK, BLUE, MUTED, BAND = "#2b2b2b", "#2a78d6", "#7d7c78", "#e9e8e4"


def rows() -> list[dict]:
    with (FAM / "expansion_interaction.csv").open() as stream:
        return [r for r in csv.DictReader(stream) if r["seeds"] == "1-3"]


def cell(row: dict, digits: int) -> str:
    def fmt(value: str) -> str:
        return f"{float(value):+.{digits}f}".replace("-", "$-$")

    return f"{fmt(row['estimate'])} [{fmt(row['low'])}, {fmt(row['high'])}]"


def pick(data: list[dict], effect: str, metric: str, dataset: str) -> dict:
    found = [
        r
        for r in data
        if r["effect"] == effect and r["metric"] == metric and r["dataset"].startswith(dataset)
    ]
    if len(found) != 1:
        raise ValueError(f"expected one row: {effect} {metric} {dataset}")
    return found[0]


def table(data: list[dict]) -> None:
    lines = [
        r"\begin{tabular}{llllll}",
        r"\toprule",
        r"Metric & Contrast & ISIC2018 & ACDC & Synapse & Pooled (label) \\",
    ]
    for metric, label, digits in METRICS:
        lines.append(r"\midrule")
        for index, (effect, name) in enumerate(EFFECTS):
            cells = [cell(pick(data, effect, metric, d), digits) for d in DATASETS]
            pooled = pick(data, effect, metric, "pooled")
            lines.append(
                f"{label if index == 0 else ''} & {name} & "
                + " & ".join(cells)
                + f" & {cell(pooled, digits)} ({pooled['classification']}) \\\\"
            )
    lines += [r"\bottomrule", r"\end{tabular}"]
    (GEN / "tab_central.tex").write_text("\n".join(lines) + "\n")


def ten_seed(first: str, second: str) -> tuple[float, float, float]:
    with (FAM / "expansion_contrasts.csv").open() as stream:
        for row in csv.DictReader(stream):
            if (row["metric"], row["first"], row["second"]) == ("boundary_f1", first, second):
                return float(row["all_delta"]), float(row["all_low"]), float(row["all_high"])
    raise ValueError(f"missing contrast {first} {second}")


def figure(data: list[dict]) -> None:
    def three(effect: str) -> list[tuple]:
        out = []
        for dataset in [*DATASETS, "pooled"]:
            r = pick(data, effect, "boundary_f1", dataset)
            kind = "pooled" if dataset == "pooled" else "three"
            name = "Pooled" if dataset == "pooled" else NAMES[dataset]
            out.append((name, float(r["estimate"]), float(r["low"]), float(r["high"]), kind))
        return out

    groups = [
        (
            "Training-only supervision:\ndecoder vs U-Net",
            [
                ("ISIC2018 (ten runs)", *ten_seed("decoder", "unet"), "ten"),
                *three("decoder without surface"),
            ],
        ),
        ("Transfer path added\nto the decoder", three("distillation+gate without surface")),
        ("Transfer path added to\ndecoder + surface loss", three("distillation+gate with surface")),
        (
            "Full recipe:\nBDS-Lite vs decoder",
            [("ISIC2018 (ten runs)", *ten_seed("full", "decoder"), "ten")],
        ),
    ]
    style = {
        "ten": dict(marker="o", color=BLUE, size=5.0, fill=BLUE, width=1.3),
        "three": dict(marker="o", color=MUTED, size=4.2, fill="white", width=0.9),
        "pooled": dict(marker="D", color=INK, size=5.0, fill=INK, width=1.3),
    }
    plt.rcParams.update({"font.size": 7, "font.family": "DejaVu Sans", "axes.linewidth": 0.5})
    fig, ax = plt.subplots(figsize=(7.0, 3.5))
    ax.axvspan(-0.01, 0.01, color=BAND, zorder=0, lw=0)
    ax.axvline(0, color=MUTED, lw=0.6, zorder=1)
    y, ticks, labels = 0.0, [], []
    for title, items in groups:
        top = y
        for name, estimate, low, high, kind in items:
            s = style[kind]
            ax.plot(
                [low, high],
                [y, y],
                color=s["color"],
                lw=s["width"],
                zorder=2,
                solid_capstyle="butt",
            )
            ax.plot(
                estimate,
                y,
                s["marker"],
                ms=s["size"],
                mfc=s["fill"],
                mec=s["color"],
                mew=0.9,
                zorder=3,
            )
            ticks.append(y)
            labels.append(name)
            y += 1
        ax.text(
            0.006,
            (top + y - 1) / 2,
            title,
            ha="left",
            va="center",
            fontsize=7,
            fontweight="bold",
            color=INK,
            transform=blended_transform_factory(fig.transFigure, ax.transData),
        )
        y += 0.7
    ax.set_yticks(ticks, labels)
    ax.set_ylim(y - 0.4, -0.8)
    ax.set_xlim(-0.06, 0.10)
    ax.set_xlabel(
        "Difference in Boundary F1 (positive favors the first arm), 95% interval", labelpad=3
    )
    ax.tick_params(length=2, width=0.4, labelsize=6.5)
    ax.tick_params(axis="y", length=0)
    for side in ("top", "right", "left"):
        ax.spines[side].set_visible(False)
    handles = [
        Line2D([], [], marker="o", color=BLUE, mfc=BLUE, ms=5, lw=1.3, label="Ten runs per arm"),
        Line2D(
            [], [], marker="o", color=MUTED, mfc="white", ms=4.2, lw=0.9, label="Three runs per arm"
        ),
        Line2D(
            [],
            [],
            marker="D",
            color=INK,
            mfc=INK,
            ms=5,
            lw=1.3,
            label="Pooled over datasets (three runs)",
        ),
        Patch(color=BAND, label="Threshold, $\\pm$0.01"),
    ]
    ax.legend(handles=handles, loc="lower right", frameon=False, fontsize=6.5, handlelength=1.8)
    fig.subplots_adjust(left=0.375, right=0.985, top=0.99, bottom=0.11)
    fig.savefig(FIG / "central_question.pdf")
    fig.savefig(FIG / "central_question.png", dpi=300)


def main() -> None:
    data = rows()
    table(data)
    figure(data)


if __name__ == "__main__":
    main()
